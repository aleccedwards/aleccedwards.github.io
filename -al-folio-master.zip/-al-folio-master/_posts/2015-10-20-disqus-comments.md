---
layout: post
title: a post with disqus comments
date: 2015-10-20 11:59:00-0400
description: an example of a blog post with disqus comments
tags: comments
categories: sample-posts external-services
disqus_comments: true
related_posts: false
---
This post shows how to add DISQUS comments.
